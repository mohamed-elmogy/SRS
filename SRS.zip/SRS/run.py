from app import app
from app import db

if __name__ == '__main__':
    app.run(debug=True)

